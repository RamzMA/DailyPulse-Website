import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, query, where } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBCZp768jAILEgoKYiae92kGwprdRkAOFU",
  authDomain: "dailypulse-e043e.firebaseapp.com",
  projectId: "dailypulse-e043e",
  storageBucket: "dailypulse-e043e.appspot.com",
  messagingSenderId: "362135589182",
  appId: "1:362135589182:web:7bca3a75b103788e2c1c6f",
  measurementId: "G-7T0DLK9Y31"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

console.log("Firebase initialized");

let currentUserUID = null;

// Check auth state
onAuthStateChanged(auth, (user) => {
  const signUpLoginButton = document.getElementById('signUpLoginButton');
  const userIcon = document.getElementById('userIcon');

  if (user) {
    console.log("User is signed in:", user);
    signUpLoginButton.style.display = 'none';
    userIcon.style.display = 'block';
    currentUserUID = user.uid;  // Store the UID of the logged-in user
    displaySleepData(); // Display data for the logged-in user
  } else {
    console.log("No user is signed in.");
    signUpLoginButton.style.display = 'block';
    userIcon.style.display = 'none';
    currentUserUID = null;
  }
});

// Toggle dropdown menu
document.getElementById('userIcon').addEventListener('click', function() {
  this.classList.toggle('show');
});

// Logout functionality
document.getElementById('logout').addEventListener('click', function() {
  signOut(auth).then(() => {
    window.location.href = '/html/signUp.html';
  }).catch((error) => {
    console.error('Sign Out Error', error);
  });
});

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.user-icon, .user-icon *')) {
    const dropdowns = document.getElementsByClassName('dropdown-menu');
    for (let i = 0; i < dropdowns.length; i++) {
      const openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

// Record sleep date and the start and end time
document.addEventListener('DOMContentLoaded', function() {
  const submitSleep = document.getElementById('submitSleep');
  const submitDate = document.getElementById('submitDate');

  submitSleep.addEventListener('click', async function() {
    console.log("Submit button clicked");
    const dateInput = document.getElementById('dateTrack').value;
    const sleepStart = document.getElementById('sleepTimeStart').value;
    const sleepEnd = document.getElementById('sleepTimeEnd').value;

    console.log("Inputs:", { dateInput, sleepStart, sleepEnd });

    if (dateInput && sleepStart && sleepEnd && currentUserUID) {
      try {
        await addDoc(collection(db, "sleepDate"), {
          userUID: currentUserUID,  
          dateRecorded: dateInput,
          sleepstart: sleepStart,
          sleepend: sleepEnd,
          timestamp: new Date()
        });
        console.log("Document successfully written!");
        displaySleepData(); 
      } catch (e) {
        console.error("Error adding document: ", e);
      }
    } else {
      console.error("All fields are required and user must be logged in.");
    }
  });

  submitDate.addEventListener('click', function() {
    const dateInput = document.getElementById('dateTrack').value;
    if (dateInput) {
      displaySleepData(dateInput); 
    } else {
      console.error("Date input is required.");
    }
  });

  // Display sleep data on page load if user is logged in
  if (currentUserUID) {
    displaySleepData();
  }
});

// Function to display sleep data, optionally filtered by date
async function displaySleepData(dateFilter = null) {
  const loggedTimesDiv = document.querySelector('.loggedTimes');
  loggedTimesDiv.innerHTML = ''; 

  if (!currentUserUID) {
    loggedTimesDiv.innerHTML = '<p>Please log in to see your sleep data.</p>';
    return;
  }

  try {
    let q = query(collection(db, "sleepDate"), where("userUID", "==", currentUserUID));
    if (dateFilter) {
      q = query(q, where("dateRecorded", "==", dateFilter));
    }

    const querySnapshot = await getDocs(q);
    if (querySnapshot.empty) {
      console.log("No documents found!");
      loggedTimesDiv.innerHTML = '<p>No sleep data logged yet.</p>';
    } else {
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        console.log("Document data:", data);
        const sleepDataDiv = document.createElement('div');
        sleepDataDiv.classList.add('sleep-data');
        sleepDataDiv.innerHTML = `
          <p>Date: ${data.dateRecorded}</p>
          <p>Sleep Start: ${data.sleepstart}</p>
          <p>Sleep End: ${data.sleepend}</p>
        `;
        loggedTimesDiv.appendChild(sleepDataDiv);
      });
    }
  } catch (e) {
    console.error("Error getting documents: ", e);
    loggedTimesDiv.innerHTML = '<p>Error loading sleep data. Please try again later.</p>';
  }
}
