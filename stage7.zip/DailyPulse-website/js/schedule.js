import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, deleteDoc, updateDoc, query, where, doc } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";
import { getMessaging, getToken, onMessage } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-messaging.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBCZp768jAILEgoKYiae92kGwprdRkAOFU",
  authDomain: "dailypulse-e043e.firebaseapp.com",
  projectId: "dailypulse-e043e",
  storageBucket: "dailypulse-e043e.appspot.com",
  messagingSenderId: "362135589182",
  appId: "1:362135589182:web:7bca3a75b103788e2c1c6f",
  measurementId: "G-7T0DLK9Y31"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const messaging = getMessaging(app);

let currentUser;

// Check auth state
onAuthStateChanged(auth, (user) => {
  const signUpLoginButton = document.getElementById('signUpLoginButton');
  const userIcon = document.getElementById('userIcon');

  if (user) {
    currentUser = user;
    console.log("User is signed in:", user);
    signUpLoginButton.style.display = 'none';
    userIcon.style.display = 'block';
    loadCalendarEvents(user.uid);
  } else {
    console.log("No user is signed in.");
    signUpLoginButton.style.display = 'block';
    userIcon.style.display = 'none';
  }
});

// Initialize the calendar
document.addEventListener('DOMContentLoaded', function() {
  var calendarEl = document.getElementById('calendar');
  var calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
    },
    editable: true,
    selectable: true,
    events: async function(fetchInfo, successCallback, failureCallback) {
      if (currentUser) {
        const events = [];
        const eventsCollection = collection(db, "users", currentUser.uid, "events");
        const querySnapshot = await getDocs(eventsCollection);
        querySnapshot.forEach((doc) => {
          const event = doc.data();
          events.push({
            id: doc.id,
            title: event.title,
            start: event.start,
            end: event.end,
            allDay: event.allDay,
            description: event.description,
            recurring: event.recurring
          });
        });
        successCallback(events);
      }
    },
    eventClick: function(info) {
      if (confirm(`Do you want to delete the event '${info.event.title}'?`)) {
        deleteDoc(doc(db, "users", currentUser.uid, "events", info.event.id)).then(() => {
          info.event.remove();
        });
      }
    },
    select: function(info) {
      var title = prompt('Name of event:');
      var description = prompt('Event Description:');
      var startTime = prompt('Event Start Time (e.g., 14:00): (optional)');
      var endTime = prompt('Event End Time (e.g., 16:00): (optional)');
      var recurring = confirm('Is this event recurring?');

      if (title) {
        let startDateTime = info.startStr;
        let endDateTime = info.endStr;

        if (startTime) {
          startDateTime = info.startStr.split('T')[0] + 'T' + startTime + ':00';
        }
        if (endTime) {
          endDateTime = info.endStr.split('T')[0] + 'T' + endTime + ':00';
        }

        const newEvent = {
          title: title,
          start: startDateTime,
          end: endDateTime,
          allDay: !startTime && !endTime,
          description: description,
          recurring: recurring
        };

        addDoc(collection(db, "users", currentUser.uid, "events"), newEvent).then((docRef) => {
          calendar.addEvent({
            id: docRef.id,
            ...newEvent
          });
        });
      }
      calendar.unselect();
    },
    eventDrop: function(info) {
      const eventRef = doc(db, "users", currentUser.uid, "events", info.event.id);
      updateDoc(eventRef, {
        start: info.event.start.toISOString(),
        end: info.event.end ? info.event.end.toISOString() : null
      });
    }
  });
  calendar.render();
});

function loadCalendarEvents(uid) {
  var calendarEl = document.getElementById('calendar');
  var calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
    },
    editable: true,
    selectable: true,
    events: async function(fetchInfo, successCallback, failureCallback) {
      const events = [];
      const eventsCollection = collection(db, "users", uid, "events");
      const querySnapshot = await getDocs(eventsCollection);
      querySnapshot.forEach((doc) => {
        const event = doc.data();
        events.push({
          id: doc.id,
          title: event.title,
          start: event.start,
          end: event.end,
          allDay: event.allDay,
          description: event.description,
          recurring: event.recurring
        });
      });
      successCallback(events);
    },
    eventClick: function(info) {
      if (confirm(`Do you want to delete the event '${info.event.title}'?`)) {
        deleteDoc(doc(db, "users", uid, "events", info.event.id)).then(() => {
          info.event.remove();
        });
      }
    },
    select: function(info) {
      var title = prompt('Name of event:');
      var description = prompt('Event Description:');
      var startTime = prompt('Event Start Time (e.g., 14:00): (optional)');
      var endTime = prompt('Event End Time (e.g., 16:00): (optional)');
      var recurring = confirm('Is this event recurring?');

      if (title) {
        let startDateTime = info.startStr;
        let endDateTime = info.endStr;

        if (startTime) {
          startDateTime = info.startStr.split('T')[0] + 'T' + startTime + ':00';
        }
        if (endTime) {
          endDateTime = info.endStr.split('T')[0] + 'T' + endTime + ':00';
        }

        const newEvent = {
          title: title,
          start: startDateTime,
          end: endDateTime,
          allDay: !startTime && !endTime,
          description: description,
          recurring: recurring
        };

        addDoc(collection(db, "users", uid, "events"), newEvent).then((docRef) => {
          calendar.addEvent({
            id: docRef.id,
            ...newEvent
          });
        });
      }
      calendar.unselect();
    },
    eventDrop: function(info) {
      const eventRef = doc(db, "users", uid, "events", info.event.id);
      updateDoc(eventRef, {
        start: info.event.start.toISOString(),
        end: info.event.end ? info.event.end.toISOString() : null
      });
    }
  });
  calendar.render();
}

// Toggle dropdown menu
document.getElementById('userIcon').addEventListener('click', function() {
  this.classList.toggle('show');
});

// Logout functionality
document.getElementById('logout').addEventListener('click', function() {
  signOut(auth).then(() => {
    window.location.href = '/html/signUp.html';
  }).catch((error) => {
    console.error('Sign Out Error', error);
  });
});

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.user-icon, .user-icon *')) {
    const dropdowns = document.getElementsByClassName('dropdown-menu');
    for (let i = 0; i < dropdowns.length; i++) {
      const openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

// Listen for messages
onMessage(messaging, (payload) => {
  console.log("Message received: ", payload);
  alert(`Reminder: ${payload.notification.title}`);
});
