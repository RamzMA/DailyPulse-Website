import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import { getDatabase, ref, set } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyBCZp768jAILEgoKYiae92kGwprdRkAOFU",
  authDomain: "dailypulse-e043e.firebaseapp.com",
  projectId: "dailypulse-e043e",
  storageBucket: "dailypulse-e043e.appspot.com",
  messagingSenderId: "362135589182",
  appId: "1:362135589182:web:7bca3a75b103788e2c1c6f",
  measurementId: "G-7T0DLK9Y31"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);

// Sign up functionality
document.getElementById('signUpButton').addEventListener('click', function() {
  var email = document.getElementById('email').value.toLowerCase();
  var confirmEmail = document.getElementById('confirmEmail').value.toLowerCase();
  var password = document.getElementById('password').value;
  var confirmPassword = document.getElementById('confirmPassword').value;

  if (email === confirmEmail && password === confirmPassword) {
    createUserWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        var user = userCredential.user;
        set(ref(database, 'users/' + user.uid), { email: email });
        alert('User signed up successfully!');
        document.getElementById('email').value = '';
        document.getElementById('confirmEmail').value = '';
        document.getElementById('password').value = '';
        document.getElementById('confirmPassword').value = '';
        window.location.href = '/html/index.html'; // Redirect to home page
      })
      .catch((error) => {
        alert('Error: ' + error.message);
        document.getElementById('email').value = '';
        document.getElementById('confirmEmail').value = '';
        document.getElementById('password').value = '';
        document.getElementById('confirmPassword').value = '';
      });
  } else {
    alert('Email or password confirmation does not match.');
    document.getElementById('email').value = '';
    document.getElementById('confirmEmail').value = '';
    document.getElementById('password').value = '';
    document.getElementById('confirmPassword').value = '';
  }
});

// Modal functionality
var modal = document.getElementById('loginModal');
var btn = document.getElementById('logInButton');
var span = document.getElementsByClassName('close')[0];

btn.onclick = function() {
  modal.style.display = 'block';
}

span.onclick = function() {
  modal.style.display = 'none';
}

window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = 'none';
  }
}

// Login functionality
document.getElementById('loginButton').addEventListener('click', function() {
  var loginEmail = document.getElementById('loginEmail').value.toLowerCase();
  var loginPassword = document.getElementById('loginPassword').value;

  signInWithEmailAndPassword(auth, loginEmail, loginPassword)
    .then((userCredential) => {
      alert('Login successful!');
      modal.style.display = 'none';
      document.getElementById('loginEmail').value = '';
      document.getElementById('loginPassword').value = '';
      window.location.href = '/html/index.html'; 
    })
    .catch((error) => {
      alert('Error: ' + error.message);
      document.getElementById('loginEmail').value = '';
      document.getElementById('loginPassword').value = '';
    });
});

// Forgot password functionality
document.getElementById('forgotPassword').addEventListener('click', function() {
  var loginEmail = document.getElementById('loginEmail').value.toLowerCase();

  if (loginEmail) {
    sendPasswordResetEmail(auth, loginEmail)
      .then(() => {
        alert('Password reset email sent!');
      })
      .catch((error) => {
        alert('Error: ' + error.message);
      });
  } else {
    alert('Please enter your email address.');
  }
});
