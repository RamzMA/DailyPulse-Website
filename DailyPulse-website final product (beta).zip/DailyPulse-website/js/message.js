import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import { getFirestore, collection, addDoc, query, onSnapshot, serverTimestamp, orderBy, doc, updateDoc } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBCZp768jAILEgoKYiae92kGwprdRkAOFU",
  authDomain: "dailypulse-e043e.firebaseapp.com",
  databaseURL: "https://dailypulse-e043e-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "dailypulse-e043e",
  storageBucket: "dailypulse-e043e.appspot.com",
  messagingSenderId: "362135589182",
  appId: "1:362135589182:web:7bca3a75b103788e2c1c6f",
  measurementId: "G-7T0DLK9Y31"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Initialize variables
let currentUser;

// Check auth state
onAuthStateChanged(auth, (user) => {
  const signUpLoginButton = document.getElementById('signUpLoginButton');
  const userIcon = document.getElementById('userIcon');

  if (user) {
    currentUser = user;
    signUpLoginButton.style.display = 'none';
    userIcon.style.display = 'block';
    loadMessages();
  } else {
    signUpLoginButton.style.display = 'block';
    userIcon.style.display = 'none';
  }
});

// Load messages from Firestore
function loadMessages() {
  const chatContent = document.getElementById('chat-content');
  const q = query(collection(db, "messages"), orderBy("timestamp"));

  onSnapshot(q, (snapshot) => {
    chatContent.innerHTML = ''; 
    snapshot.forEach((doc) => {
      const message = doc.data();
      const messageDiv = document.createElement('div');
      messageDiv.classList.add('message');
      messageDiv.textContent = `${message.username}: ${message.text}`;
      messageDiv.dataset.id = doc.id; 
      if (message.uid === currentUser.uid) {
        messageDiv.classList.add('own-message');
        messageDiv.addEventListener('click', () => deleteMessage(doc.id));
      }
      chatContent.appendChild(messageDiv);
    });
    chatContent.scrollTop = chatContent.scrollHeight; 
  }, (error) => {
    console.error("Error loading messages: ", error);
  });
}

// Send a new message to Firestore
async function sendMessage() {
  const messageInput = document.getElementById('message-input');
  const text = messageInput.value;

  if (text.trim() === '') return; 

  try {
    await addDoc(collection(db, "messages"), {
      text: text,
      username: currentUser.email,
      uid: currentUser.uid, 
      timestamp: serverTimestamp()
    });
    messageInput.value = ''; 
  } catch (error) {
    console.error("Error adding message: ", error);
  }
}

// Delete a message from Firestore
async function deleteMessage(messageId) {
  try {
    const messageRef = doc(db, "messages", messageId);
    await updateDoc(messageRef, { text: "Message deleted" });
  } catch (error) {
    console.error("Error deleting message: ", error);
  }
}

// Event listener for send button
document.getElementById('send-button').addEventListener('click', sendMessage);

// Event listener for Enter key in message input
document.getElementById('message-input').addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    sendMessage();
  }
});

// Logout functionality
document.getElementById('logout').addEventListener('click', () => {
  signOut(auth).then(() => {
    window.location.href = '/html/signUp.html';
  }).catch((error) => {
    console.error('Sign Out Error', error);
  });
});

// Toggle dropdown menu
document.getElementById('userIcon').addEventListener('click', function() {
  this.classList.toggle('show');
});
