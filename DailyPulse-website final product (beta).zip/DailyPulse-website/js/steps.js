import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import { getFirestore, doc, getDoc } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBCZp768jAILEgoKYiae92kGwprdRkAOFU",
  authDomain: "dailypulse-e043e.firebaseapp.com",
  projectId: "dailypulse-e043e",
  storageBucket: "dailypulse-e043e.appspot.com",
  messagingSenderId: "362135589182",
  appId: "1:362135589182:web:7bca3a75b103788e2c1c6f",
  measurementId: "G-7T0DLK9Y31"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Check auth state
onAuthStateChanged(auth, (user) => {
  const signUpLoginButton = document.getElementById('signUpLoginButton');
  const userIcon = document.getElementById('userIcon');

  if (user) {
    console.log("User is signed in:", user);
    if (signUpLoginButton) signUpLoginButton.style.display = 'none';
    if (userIcon) userIcon.style.display = 'block';
    fetchUserData(user.uid);  
  } else {
    console.log("No user is signed in.");
    if (signUpLoginButton) signUpLoginButton.style.display = 'block';
    if (userIcon) userIcon.style.display = 'none';
  }
});

// Logout functionality
document.getElementById('logout').addEventListener('click', function() {
  signOut(auth).then(() => {
    window.location.href = '/html/signUp.html';
  }).catch((error) => {
    console.error('Sign Out Error', error);
  });
});

// Fetch user data from Firestore
async function fetchUserData(userId) {
  const docRef = doc(db, "users", userId);
  const docSnap = await getDoc(docRef);

  if (docSnap.exists()) {
    const userData = docSnap.data();
    updateUI(userData);
  } else {
    console.log("No such document!");
  }
}

// Update UI with user data
function updateUI(data) {
  const stepGraphText = document.getElementById('stepGraphText');
  const stepGraphFill = document.getElementById('stepGraphFill');
  const caloriesText = document.getElementById('calories');

  stepGraphText.innerText = data.steps || 0;
  caloriesText.innerText = data.calories || 0;

  let stepsDone = (data.steps || 0) / 10000;  
  stepGraphFill.style.transform = `scaleY(${stepsDone})`;
  stepGraphFill.style.animation = `fillUp 2s ease forwards`;
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.user-icon, .user-icon *')) {
    const dropdowns = document.getElementsByClassName('dropdown-menu');
    for (let i = 0; i < dropdowns.length; i++) {
      const openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
