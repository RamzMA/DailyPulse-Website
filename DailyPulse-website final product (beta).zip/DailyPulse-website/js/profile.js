import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import { getFirestore, doc, getDoc, updateDoc } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBCZp768jAILEgoKYiae92kGwprdRkAOFU",
  authDomain: "dailypulse-e043e.firebaseapp.com",
  projectId: "dailypulse-e043e",
  storageBucket: "dailypulse-e043e.appspot.com",
  messagingSenderId: "362135589182",
  appId: "1:362135589182:web:7bca3a75b103788e2c1c6f",
  measurementId: "G-7T0DLK9Y31"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Check auth state
onAuthStateChanged(auth, (user) => {
  if (user) {
    console.log("User is signed in:", user);
    fetchUserProfile(user.uid);
  } else {
    console.log("No user is signed in.");
    window.location.href = '/html/signUp.html';
  }
});

// Fetch user profile from Firestore
async function fetchUserProfile(userId) {
  const docRef = doc(db, "users", userId);
  const docSnap = await getDoc(docRef);

  if (docSnap.exists()) {
    const userData = docSnap.data();
    displayUserProfile(userData);
  } else {
    console.log("No such document!");
  }
}

// Display user profile data
function displayUserProfile(data) {
  document.getElementById('userName').innerText = data.name || 'N/A';
  document.getElementById('userEmail').innerText = data.email || 'N/A';
  document.getElementById('userSteps').innerText = data.steps || 0;
  document.getElementById('userCalories').innerText = data.calories || 0;
}

// Logout functionality
document.getElementById('logout').addEventListener('click', function() {
  signOut(auth).then(() => {
    window.location.href = '/html/signUp.html';
  }).catch((error) => {
    console.error('Sign Out Error', error);
  });
});

// Handle Edit Profile
document.getElementById('editProfileButton').addEventListener('click', function() {
  const newName = prompt("Enter new name:");
  if (newName) {
    updateProfile({ name: newName });
  }
});

// Update profile in Firestore
async function updateProfile(updates) {
  const user = auth.currentUser;
  if (user) {
    const docRef = doc(db, "users", user.uid);
    await updateDoc(docRef, updates);
    fetchUserProfile(user.uid);  // Refresh profile data
  }
}
