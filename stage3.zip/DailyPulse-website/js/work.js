import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, updateDoc, deleteDoc, doc } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBCZp768jAILEgoKYiae92kGwprdRkAOFU",
  authDomain: "dailypulse-e043e.firebaseapp.com",
  projectId: "dailypulse-e043e",
  storageBucket: "dailypulse-e043e.appspot.com",
  messagingSenderId: "362135589182",
  appId: "1:362135589182:web:7bca3a75b103788e2c1c6f",
  measurementId: "G-7T0DLK9Y31"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Check auth state
onAuthStateChanged(auth, (user) => {
  const signUpLoginButton = document.getElementById('signUpLoginButton');
  const userIcon = document.getElementById('userIcon');

  if (user) {
    console.log("User is signed in:", user);
    signUpLoginButton.style.display = 'none';
    userIcon.style.display = 'block';
  } else {
    console.log("No user is signed in.");
    signUpLoginButton.style.display = 'block';
    userIcon.style.display = 'none';
  }
});

// Toggle dropdown menu
document.getElementById('userIcon').addEventListener('click', function() {
  this.classList.toggle('show');
});

// Logout functionality
document.getElementById('logout').addEventListener('click', function() {
  signOut(auth).then(() => {
    window.location.href = '/html/signUp.html';
  }).catch((error) => {
    console.error('Sign Out Error', error);
  });
});

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.user-icon, .user-icon *')) {
    const dropdowns = document.getElementsByClassName('dropdown-menu');
    for (let i = 0; i < dropdowns.length; i++) {
      const openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
};

// To-do list functionality
document.addEventListener('DOMContentLoaded', function() {
  const addTaskButton = document.querySelector('.addTask button');
  const taskInput = document.querySelector('.addTask input');
  const notCompletedList = document.querySelector('.notCompleted');
  const completedList = document.querySelector('.completed');

  addTaskButton.addEventListener('click', addTask);
  taskInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      addTask();
    }
  });

  async function addTask() {
    const taskValue = taskInput.value.trim();
    if (taskValue) {
      try {
        const docRef = await addDoc(collection(db, "tasks"), {
          text: taskValue,
          completed: false,
          timestamp: new Date()
        });

        const li = document.createElement('li');
        li.dataset.id = docRef.id;  // Save the document ID in the DOM element
        li.innerHTML = `${taskValue}
          <button class="complete"><i class="fa fa-check"></i></button>
          <button class="delete"><i class="fa fa-trash"></i></button>`;
        notCompletedList.appendChild(li);
        taskInput.value = '';
      } catch (e) {
        console.error("Error adding document: ", e);
      }
    }
  }

  notCompletedList.addEventListener('click', handleTaskAction);
  completedList.addEventListener('click', handleTaskAction);

  async function handleTaskAction(e) {
    const taskItem = e.target.closest('li');
    const taskId = taskItem.dataset.id;

    if (e.target.classList.contains('fa-check')) {
      try {
        await updateDoc(doc(db, "tasks", taskId), { completed: true });
        taskItem.querySelector('.complete').remove();
        completedList.appendChild(taskItem);
      } catch (e) {
        console.error("Error updating document: ", e);
      }
    } else if (e.target.classList.contains('fa-trash')) {
      try {
        await deleteDoc(doc(db, "tasks", taskId));
        taskItem.remove();
      } catch (e) {
        console.error("Error deleting document: ", e);
      }
    }
  }

  async function loadTasks() {
    const querySnapshot = await getDocs(collection(db, "tasks"));
    querySnapshot.forEach((doc) => {
      const task = doc.data();
      const li = document.createElement('li');
      li.dataset.id = doc.id;
      li.innerHTML = `${task.text}
        ${!task.completed ? '<button class="complete"><i class="fa fa-check"></i></button>' : ''}
        <button class="delete"><i class="fa fa-trash"></i></button>`;
      if (task.completed) {
        completedList.appendChild(li);
      } else {
        notCompletedList.appendChild(li);
      }
    });
  }

  loadTasks();
});
