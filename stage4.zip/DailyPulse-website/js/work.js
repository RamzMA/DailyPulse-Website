import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, updateDoc, deleteDoc, doc } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBCZp768jAILEgoKYiae92kGwprdRkAOFU",
  authDomain: "dailypulse-e043e.firebaseapp.com",
  projectId: "dailypulse-e043e",
  storageBucket: "dailypulse-e043e.appspot.com",
  messagingSenderId: "362135589182",
  appId: "1:362135589182:web:7bca3a75b103788e2c1c6f",
  measurementId: "G-7T0DLK9Y31"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Check auth state
onAuthStateChanged(auth, (user) => {
  const signUpLoginButton = document.getElementById('signUpLoginButton');
  const userIcon = document.getElementById('userIcon');

  if (user) {
    console.log("User is signed in:", user);
    signUpLoginButton.style.display = 'none';
    userIcon.style.display = 'block';
  } else {
    console.log("No user is signed in.");
    signUpLoginButton.style.display = 'block';
    userIcon.style.display = 'none';
  }
});

// Toggle dropdown menu
document.getElementById('userIcon').addEventListener('click', function() {
  this.classList.toggle('show');
});

// Logout functionality
document.getElementById('logout').addEventListener('click', function() {
  signOut(auth).then(() => {
    window.location.href = '/html/signUp.html';
  }).catch((error) => {
    console.error('Sign Out Error', error);
  });
});

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.user-icon, .user-icon *')) {
    const dropdowns = document.getElementsByClassName('dropdown-menu');
    for (let i = 0; i < dropdowns.length; i++) {
      const openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
};

// Section switching
document.addEventListener('DOMContentLoaded', function() {
  const todoButton = document.getElementById('todoButton');
  const timerButton = document.getElementById('timerButton');
  const scheduleButton = document.getElementById('scheduleButton');
  const todoSection = document.getElementById('todoSection');
  const timerSection = document.getElementById('timerSection');
  const scheduleSection = document.getElementById('scheduleSection');

  todoButton.addEventListener('click', () => switchSection(todoSection));
  timerButton.addEventListener('click', () => switchSection(timerSection));
  scheduleButton.addEventListener('click', () => switchSection(scheduleSection));

  function switchSection(section) {
    document.querySelectorAll('.section').forEach(sec => sec.style.display = 'none');
    section.style.display = 'block';
  }

  // To-do list functionality
  const addTaskButton = document.querySelector('.addTask button');
  const taskInput = document.querySelector('.addTask input[type="text"]');
  const dateInput = document.querySelector('.addTask input[type="date"]');
  const notCompletedList = document.querySelector('.notCompleted');
  const completedList = document.querySelector('.completed');

  addTaskButton.addEventListener('click', addTask);
  taskInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      addTask();
    }
  });

  async function addTask() {
    const taskValue = taskInput.value.trim();
    const dueDateValue = dateInput.value;
    if (taskValue) {
      try {
        const taskData = {
          text: taskValue,
          completed: false,
          timestamp: new Date()
        };

        if (dueDateValue) {
          taskData.dueDate = dueDateValue;
        } else {
          taskData.dueDate = "No Due Date";
        }

        const docRef = await addDoc(collection(db, "tasks"), taskData);

        const li = document.createElement('li');
        li.dataset.id = docRef.id;
        li.innerHTML = `${taskValue} - Due: ${taskData.dueDate}
          <button class="complete"><i class="fa fa-check"></i></button>
          <button class="delete"><i class="fa fa-trash"></i></button>`;
        notCompletedList.appendChild(li);
        taskInput.value = '';
        dateInput.value = '';
      } catch (e) {
        console.error("Error adding document: ", e);
      }
    }
  }

  notCompletedList.addEventListener('click', handleTaskAction);
  completedList.addEventListener('click', handleTaskAction);

  async function handleTaskAction(e) {
    const taskItem = e.target.closest('li');
    const taskId = taskItem.dataset.id;

    if (e.target.classList.contains('fa-check')) {
      try {
        await updateDoc(doc(db, "tasks", taskId), { completed: true });
        taskItem.querySelector('.complete').remove();
        completedList.appendChild(taskItem);
      } catch (e) {
        console.error("Error updating document: ", e);
      }
    } else if (e.target.classList.contains('fa-trash')) {
      try {
        await deleteDoc(doc(db, "tasks", taskId));
        taskItem.remove();
      } catch (e) {
        console.error("Error deleting document: ", e);
      }
    }
  }

  async function loadTasks() {
    const querySnapshot = await getDocs(collection(db, "tasks"));
    querySnapshot.forEach((doc) => {
      const task = doc.data();
      const li = document.createElement('li');
      li.dataset.id = doc.id;
      li.innerHTML = `${task.text} - Due: ${task.dueDate}
        ${!task.completed ? '<button class="complete"><i class="fa fa-check"></i></button>' : ''}
        <button class="delete"><i class="fa fa-trash"></i></button>`;
      if (task.completed) {
        completedList.appendChild(li);
      } else {
        notCompletedList.appendChild(li);
      }
    });
  }

  loadTasks();

  // Timer 
  const startBtn = document.getElementById('startBtn');
  const pauseBtn = document.getElementById('pauseBtn');
  const resetBtn = document.getElementById('resetBtn');
  const timeDisplay = document.getElementById('timeDisplay');
  const pauseTimes = document.getElementById('pauseTimes');

  let startTime, elapsedTime = 0, timerInterval;

  startBtn.addEventListener('click', startTimer);
  pauseBtn.addEventListener('click', pauseTimer);
  resetBtn.addEventListener('click', resetTimer);

  function startTimer() {
    startTime = Date.now() - elapsedTime;
    timerInterval = setInterval(updateTime, 10);
    startBtn.disabled = true;
    pauseBtn.disabled = false;
  }

  function pauseTimer() {
    clearInterval(timerInterval);
    const pausedTime = new Date(elapsedTime).toISOString().slice(11, -1);
    savePausedTime(pausedTime);
    displayPausedTime(pausedTime);
    startBtn.disabled = false;
    pauseBtn.disabled = true;
  }

  function resetTimer() {
    clearInterval(timerInterval);
    startTime = 0;
    elapsedTime = 0;
    timeDisplay.textContent = '00:00:00:000';
    startBtn.disabled = false;
    pauseBtn.disabled = true;
    pauseTimes.innerHTML = '<h2>Paused Times:</h2>';
  }

  function updateTime() {
    elapsedTime = Date.now() - startTime;
    timeDisplay.textContent = timeToString(elapsedTime);
  }

  function timeToString(time) {
    let diffInHrs = time / 3600000;
    let hh = Math.floor(diffInHrs);

    let diffInMin = (diffInHrs - hh) * 60;
    let mm = Math.floor(diffInMin);

    let diffInSec = (diffInMin - mm) * 60;
    let ss = Math.floor(diffInSec);

    let diffInMs = (diffInSec - ss) * 1000;
    let ms = Math.floor(diffInMs);

    let formattedHH = hh.toString().padStart(2, "0")
    let formattedMM = mm.toString().padStart(2, "0");
    let formattedSS = ss.toString().padStart(2, "0");
    let formattedMS = ms.toString().padStart(3, "0");

    return `${formattedHH}:${formattedMM}:${formattedSS}:${formattedMS}`;
  }

  async function savePausedTime(pausedTime) {
    try {
      await addDoc(collection(db, "pausedTimes"), {
        pausedTime: pausedTime,
        timestamp: new Date()
      });
    } catch (e) {
      console.error("Error adding document: ", e);
    }
  }

  async function displayPausedTime(pausedTime) {
    const p = document.createElement('p');
    p.textContent = `Paused at: ${pausedTime}`;
    pauseTimes.appendChild(p);
  }
});
