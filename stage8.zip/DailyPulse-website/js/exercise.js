import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBCZp768jAILEgoKYiae92kGwprdRkAOFU",
  authDomain: "dailypulse-e043e.firebaseapp.com",
  projectId: "dailypulse-e043e",
  storageBucket: "dailypulse-e043e.appspot.com",
  messagingSenderId: "362135589182",
  appId: "1:362135589182:web:7bca3a75b103788e2c1c6f",
  measurementId: "G-7T0DLK9Y31"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

let currentUser;
let currentDay = "pushDay";

// Check auth state
onAuthStateChanged(auth, (user) => {
  const signUpLoginButton = document.getElementById('signUpLoginButton');
  const userIcon = document.getElementById('userIcon');

  if (user) {
    currentUser = user;
    console.log("User is signed in:", user);
    signUpLoginButton.style.display = 'none';
    userIcon.style.display = 'block';
    loadWorkoutsForDay(currentDay);
  } else {
    console.log("No user is signed in.");
    signUpLoginButton.style.display = 'block';
    userIcon.style.display = 'none';
  }
});

// Load workouts for the selected day
function loadWorkoutsForDay(day) {
  const workoutsResults = document.getElementById('workoutsHere');
  workoutsResults.innerHTML = ''; 

  if (currentUser) {
    const workoutsCollection = collection(db, "users", currentUser.uid, day);
    getDocs(workoutsCollection).then((querySnapshot) => {
      querySnapshot.forEach((doc) => {
        const workout = doc.data();
        const workoutDiv = document.createElement('div');
        workoutDiv.textContent = workout.message ? workout.message : `${workout.date}: ${workout.name}`;
        workoutsResults.appendChild(workoutDiv);
      });
    });
  }
}

// Event listeners for the buttons
document.addEventListener('DOMContentLoaded', function() {
  const pushDayButton = document.getElementById('pushDay');
  const pullDayButton = document.getElementById('pullDay');
  const legDayButton = document.getElementById('legDay');
  const absDayButton = document.getElementById('absDay');
  const workoutButton = document.getElementById('workoutButton');
  const doneButton = document.getElementById('done');
  const workoutInput = document.getElementById('workout');

  // Function to handle day button clicks
  function handleDayButtonClick(day) {
    currentDay = day;
    loadWorkoutsForDay(currentDay);
    document.querySelectorAll('.exercise-button').forEach(btn => btn.classList.remove('active'));
    document.getElementById(day).classList.add('active');
  }

  pushDayButton.addEventListener('click', () => handleDayButtonClick('pushDay'));
  pullDayButton.addEventListener('click', () => handleDayButtonClick('pullDay'));
  legDayButton.addEventListener('click', () => handleDayButtonClick('legDay'));
  absDayButton.addEventListener('click', () => handleDayButtonClick('absDay'));

  // Function to submit the workout
  function submitWorkout() {
    const workoutName = workoutInput.value;
    const currentDate = new Date().toLocaleDateString();
    if (workoutName && currentUser) {
      addDoc(collection(db, "users", currentUser.uid, currentDay), { name: workoutName, date: currentDate }).then(() => {
        const workoutDiv = document.createElement('div');
        workoutDiv.textContent = `${currentDate}: ${workoutName}`;
        document.getElementById('workoutsHere').appendChild(workoutDiv);
        workoutInput.value = ''; 
      });
    }
  }

  // Event listener for the workout submission button
  workoutButton.addEventListener('click', submitWorkout);

  // Event listener for pressing the Enter key to submit the workout
  workoutInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
      submitWorkout();
    }
  });

  // Event listener for the done button
  doneButton.addEventListener('click', () => {
    const currentDate = new Date().toLocaleDateString();
    const doneMessage = `----------- ${currentDate}: ${currentDay} is over -----------`;

    if (currentUser) {
      addDoc(collection(db, "users", currentUser.uid, currentDay), { message: doneMessage }).then(() => {
        const workoutsResults = document.getElementById('workoutsHere');
        const doneDiv = document.createElement('div');
        doneDiv.textContent = doneMessage;
        workoutsResults.appendChild(doneDiv);
      });
    }
  });
});

// Toggle dropdown menu
document.getElementById('userIcon').addEventListener('click', function() {
  this.classList.toggle('show');
});

// Logout functionality
document.getElementById('logout').addEventListener('click', function() {
  signOut(auth).then(() => {
    window.location.href = '/html/signUp.html';
  }).catch((error) => {
    console.error('Sign Out Error', error);
  });
});
